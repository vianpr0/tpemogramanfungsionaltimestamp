<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Timestamp Conversion</title>
</head>
<body>
    <h1>Hasil Konversi Timestamp Yos </h1>
    <p><strong>Tanggal dan Waktu:</strong> <?php echo e($dateTime); ?></p>
    
    <p><strong>Formatted Date:</strong> <?php echo e($formattedDate); ?></p>
    <p><strong>Nama Bulan (Panjang):</strong> <?php echo e($monthNames['long']); ?></p>
    <p><strong>Nama Bulan (Pendek):</strong> <?php echo e($monthNames['short']); ?></p>
    <p><strong>Format Lengkap dengan Jam:</strong> <?php echo e($fullDateTime); ?></p>
    <p><strong>Format Singkat (Tanggal):</strong> <?php echo e($shortDate); ?></p>
</body>
</html>
<?php /**PATH E:\WEB 3.0\Laravel\laravelfungsional\resources\views/timestamp.blade.php ENDPATH**/ ?>